Este es el trabajo final del módulo PHP . Aquí explicaré el trabajo realizado en esta práctica :

1) INICIO
	
	 - Se cargará las clasificiaciones de todos los equipos guardada en la base de datos y 
	   se cargará también las noticias rss utilizando PHP

	 - Si está en modo admin el administrador podrá modificar los valores de las columnas
	 	GOLES A FAVOR , GOLES EN CONTRA y PUNTOS 

2) EQUIPOS 

	- Se cargará una columna donde se mostrará todos los equipos

	- Si clickas uno de los equipos se mostrará la ficha completa ( En el directorio de images no están todos los jugadores completos ) : Nombre del equipo y su logo , su estadio , su entrenador , su clasificación y sus jugadores (4)

3) CLASIFICACIÓN 

	- Se cargará la clasificación completa de todos los equipos 

	- Si está en modo admin al igual que en el incio se podrán modificar las columnas exceptuando las columnas CLASIFICACIÓN E EQUIPOS

4) PARTIDOS

	-Se cargarán todos los partidos ya jugados 

	-Si está en modo admin aparecerá un formulario debajo de la página para que puedas añadir o borrar partidos

5) NOTICIAS

	- En este apartado solamente cargará las noticias almacenados en la base de datos

6) APUESTAS

	- Si el usuario no está logueado aparecerá dos formularios para loguear o registrar

	- Si te registras , la apuesta será opcional

	- Si el usuario está conectado entonces le aparecerán los datos de su apuesta

	- Si el usuario no ha apostado y está conectado le aparecerá un formulario para apostar

	NOTA : El usuario solo podrá apostar una vez ya que al apostar no le aparecerá un formulario para apostar

7) CONTACTO

	- Se cargará un formulario para enviar un correo 

8) TABLAS en la base de datos 'liga'
	
	Nombre		Columnas

	admin 		username , psw
	apuestas 	id_usuario,id_partido,apuesta,gol_1,gol_2
	clasificación	id_equipo,puntos,goles_favor,goles_contra,PJ,V,E,D
	entrenadores	id,id_equipo,nombre,image
	equipos		id, equipos, image
	estadios	id_equipo,nombre,image
	jugadores	id,id_equipo,nombre,image
	noticias	id,titulo,contenido,fecha
	partidos	id,id_equipo_1,id_equipo_2,gol_1,gol_2,fecha
	usuarios	id,username,psw


	NOTA : la columna image es solamente el nombre de la imagen con su extensión	 









