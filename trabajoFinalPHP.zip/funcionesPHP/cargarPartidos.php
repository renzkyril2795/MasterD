<?php  
	
	include 'config.php';
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die("Error en la conexión ");
	mysql_select_db(DB) or die("Error en la selección de base de datos");
	//selcciona todos los partidos
	$sql = "SELECT equipoA.equipos AS equipoA , equipoA.image AS equipoA_image , equipoB.equipos AS equipoB , equipoB.image AS equipoB_image , partidos.gol_1 AS golA, partidos.gol_2 AS golB , partidos.fecha FROM partidos , equipos AS equipoA , equipos AS equipoB WHERE equipoA.id = partidos.id_equipo_1 AND equipoB.id = partidos.id_equipo_2 ";
	mysql_query("SET CHARACTER SET utf8");
	mysql_query("SET NAMES utf8");
	$result = mysql_query($sql) or die("error en el query");
	// y devolvemos el html de abajo
	echo "<table><tr><td> HOME </td><td> VISITOR </td><td> GOL HOME </td><td> GOL VISITOR </td><td> FECHA </td></tr>";
	while($fila = mysql_fetch_array($result)){

			echo "<tr><td><img class='equipo' src ='images/equipos/".$fila['equipoA_image']."' alt='".$fila['equipoA']."'>".$fila['equipoA']."</td>";
			echo "<td><img class='equipo' src ='images/equipos/".$fila['equipoB_image']."' alt='".$fila['equipoB']."'>".$fila['equipoB']."</td>";
			echo "<td>".$fila['golA']."</td><td>".$fila['golB']."</td><td>".$fila['fecha']."</td></tr>";
	}

	echo "</table>";

	mysql_close($conn);
?>