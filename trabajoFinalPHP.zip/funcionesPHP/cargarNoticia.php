<?php  
	// cargamos las noticias del rss enviado
	$rss = simplexml_load_file($_POST['rss']);

	echo '<h1>'. $rss->channel->title . '</h1>';

	$indice = 0;
	foreach ($rss->channel->item as $item) {
		if($indice < $_POST['num']){
			   echo "<div class='noticia'>";
			   		echo "<div class='title-date'>";
				   		echo '<h2>' . $item->title . "</h2>";
				   		echo "<p class='date'>" . $item->pubDate . "</p>";
				   	echo "</div>";
			   		echo "<div class='description'>" . $item->description . "</div>";
			   echo "</div>";
			   $indice++;
		}else{
			break;
		}
	}
?>