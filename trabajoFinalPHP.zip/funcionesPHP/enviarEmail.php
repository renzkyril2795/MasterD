<?php  
		
		 require_once("class.phpmailer.php");
	     require_once("class.smtp.php");
	     //creamos el objeto
	     $mail = new PHPMailer(true);
	     //pasamos los parametros
	     $mail->isMail();
		$mail->SMTPAuth = true;
		$mail->SMTPSecure = "ssl";
		$mail->Host = "smtp.gmail.com";
		$mail->Port = 465;
		$mail->Username = "tuEmail@gmail.com";
		//aqui hay que poner la cuenta real
		$mail->Password = "tuPassword"; //poner la clave del correo 
		$mail->SetFrom("tuEmail", $_POST['name']); //aqui hay que poner la cuenta real
		//rellenamos el email con el contenido del formulario 
		$mail->Subject = $_POST['subject']". Enviado por ".$_POST['name']; 
		$$contenido = "Nombre: ".$_POST["name"]."<br/>"; 
		$contenido .= "Email: ".$_POST["email"]."<br/>";  
		$contenido .= "Observaciones: ".$_POST["descripcion"]."<br/>";
		$mail->MsgHTML($contenido);
		//indicamos la cuenta de destino 
		$mail->AddAddress("tuEmail", 'Contacto');
		if(!$mail->Send()) {
     		echo "Error: " . $mail->ErrorInfo;
     	} else {
     		echo "Gracias por ponerte en contacto con nosotros !";
     	}
?>