<?php  

	include 'config.php';
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die(" Error en la conexión ");
	mysql_select_db(DB) or die("Error en la selección de base de datos");
	// si es para registrar usuario entonces insertamos el nuevo usuario a DB 
	if(!isset($_SESSION['user']) || !isset($_SESSION['pass'])){
		$username = mysql_real_escape_string(strip_tags($_POST['usuario']));
		$psw = md5(mysql_real_escape_string(strip_tags($_POST['contra'])));
		$sql = 'INSERT INTO usuarios (username,psw) VALUES ("'.$username.'","'.$psw.'")';
		$result = mysql_query($sql) or die("<script> alert('Usuario existente') </script>");
	}else{
		$username = $_SESSION['user'];
		$psq = $_SESSION['pass'];
	}
	//selecionamos el id del usuario que va a apostar y lo registramos
	$sql = 'SELECT id FROM usuarios WHERE psw="'.$psw.'" AND username="'.$username.'"';
	$result = mysql_query($sql) or die("Error en el query psw");
	$id = mysql_fetch_array($result)['id'];
	//ten en cuenta que al registrar los campos para apostar es opcional pero si ha introducido las apuestas
	//miraremos que no todos están rellenados si lo están entonces registraremos la apuesta con el usuario correspondinte
	if(!empty($_POST['gol_1']) && !empty($_POST['gol_2'])){


		$sql = 'INSERT INTO apuestas (id_usuario,id_partido,apuesta,gol_1,gol_2) VALUES ('.$id.','.$_POST['partidos'].','.$_POST['cantidad'].','.$_POST['gol_1'].','.$_POST['gol_2'].')';
			mysql_query($sql) or die("script> alert('error en la apuesta!') </script>");
	}
	//cerramos la conexión
	mysql_close($conn);
?>