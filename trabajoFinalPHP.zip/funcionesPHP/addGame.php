<?php  
	include 'config.php';
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die(" Error en la conexión");
	mysql_select_db(DB) or die("Error en la selección de base de datos");

	$gol_1 = 0;
	$gol_2 = 0;

	if(!empty($_POST['gol_1']) && !empty($_POST['gol_2']) ){
		$gol_1 = $_POST['gol_1'];
		$gol_2 = $_POST['gol_2'];
	}
	//insertamos un partido 
	$sql = 'INSERT INTO partidos (id_equipo_1,id_equipo_2,gol_1,gol_2,fecha) VALUES ('.$_POST['home'].','.$_POST['visitor'].','.$gol_1.','.$gol_2.',"'.$_POST['date'].'")' ;
	mysql_query($sql) or die(" Error al insertar registro !");

	echo " Registro insertado !";

?>