<?php  
	//cargamos las noticias almacenados en la base de datos
	include 'config.php';
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die("Error en la conexión");
	mysql_select_db(DB) or die("Error en la selección de base de datos");
	$sql = "SELECT * FROM noticias";
	mysql_query("SET CHARACTER SET utf8");
	mysql_query("SET NAMES utf8");
	$result = mysql_query($sql) or die("Error en el query");

	if($fila = mysql_fetch_array($result)){

		echo "<div class='noticia-principal'>";
		echo "<h2>".$fila['titulo']."</h2>";
		echo "<p>".$fila['contenido']."</p>";
		echo "</div>";

	}


	while ($fila = mysql_fetch_array($result)) {
		

		echo "<div class='noticia'>";
		echo "<h2>".$fila['titulo']."</h2>";
		echo "<p>".$fila['contenido']."</p>";
		echo "</div>";

	}

	mysql_close($conn);
?>