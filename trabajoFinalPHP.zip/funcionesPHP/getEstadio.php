<?php  
	//devuelve el nombre del estadio
	session_start();
	echo $_SESSION['estadio'];
?>