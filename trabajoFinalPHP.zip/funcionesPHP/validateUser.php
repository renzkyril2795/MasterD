<?php  
	
	include 'config.php';
	//iniciamos sessión para el usuario
	session_start();
	//El timezone será Europe/Madrid
	date_default_timezone_set("Europe/Madrid");
	//conectamos a la base de datos
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die("Error en la conexión");
	mysql_select_db(DB);
	//filtramos las entradas para mayor seguridad
	$username = mysql_real_escape_string(strip_tags($_POST['usuario']));
	$psw = md5(mysql_real_escape_string(strip_tags($_POST['contra'])));
	//Extraemos el usuario
	$sql = 'SELECT * FROM usuarios WHERE psw="'.$psw.'" AND username="'.$username.'"';
	$result = mysql_query($sql);
	//si existe los asignamos a la sessión que les correspone 
	//si_no avisamos al usuario que ha introducido mal sus credenciales
	if(mysql_num_rows($result)!=0){

		$_SESSION['user'] = $username;
		$_SESSION['pass'] = $psw;
		$_SESSION['conectado'] = "conectado";

	}else{
		echo "Usuario/Contraseña incorrecta";
	}
?>