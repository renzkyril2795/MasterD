<?php 
	include 'config.php';
	class admin {

		private $username;
		private $password;
		private $error;
		private $conn ;
		private $length;
		/**
		* Inicializa username , password y error del administrador
		*/
		function admin(){
			$this->conn = @mysql_connect(HOSTNAME,USERNAME,PASSWORD);
			if($this->conn){
				if (mysql_select_db(DB)===TRUE) {
					
					$sql = "SELECT * FROM admin ";
					$result = mysql_query($sql);
					if($result){
						if (mysql_num_rows($result)!=0) {
							 $administrator = mysql_fetch_array($result);
							 $this->length = count($administrator);
							 $this->username = $administrator['username'];
							 $this->password = $administrator['psw'];
							 mysql_free_result($result);
						}else{
							$this->error = " no hay ningún registro ";
						}
								
					}else{
						$this->error = " error en query ";
					}
				}else{
					$this->error = " error en la selección de db";
				}
			}else {
				$this->error = " error en la conexión";
			}
		}

		/**
		* devuelve el username
		*/
		function getUsername(){
			return $this->username;
		}

		/**
		* 	devuelve la contraseña
		*/
		function getPassword(){
			return $this->password;
		}
		/**
		* 	devuelve el mensaje de error
		*/
		function getError(){
			return $this->error;
		}

		function longitud(){
			return $this->length;
		}

		function close(){
			mysql_close($this->conn);
		}



	}
?>