<?php  
	session_start();
	include 'config.php';
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD);
	$nombre = $_POST['name'];
	if($conn){

		if(mysql_select_db(DB)===TRUE){
			//obtenemos el id y la imagen del equipo seleccionado
			$sql = "SELECT * FROM equipos WHERE equipos.equipos='".$nombre."'";
			mysql_query("SET CHARACTER SET utf8");
			mysql_query("SET NAMES utf8");
			$result = mysql_query($sql);
			if($result){
				if(mysql_num_rows($result)!=0){
					$fila=mysql_fetch_array($result);
					$image = $fila['image'];
					$id = $fila['id'];
				}else{
					echo " ningún resultado en equipos";
				}
				mysql_free_result($result);
			}else{
				echo "error en el query";
			}
			//obtenemso su clasificación , su entrenado y su estadio y lo devolvemos
			$sql = "SELECT clasificacion.puntos AS puntos, clasificacion.goles_favor AS gf, clasificacion.goles_contra AS gc, estadios.nombre AS estadio, estadios.image AS estadio_image  ,entrenadores.nombre AS entrenador , entrenadores.image AS entrenador_image FROM clasificacion  ";
			$sql .= "INNER JOIN estadios ON estadios.id_equipo=".$id." ";
			$sql .= "INNER JOIN entrenadores ON entrenadores.id_equipo=".$id;
			$sql .=" WHERE clasificacion.id_equipo=".$id;
			$result = mysql_query($sql);
			if($result){

				if(mysql_num_rows($result)!=0){
					$fila = mysql_fetch_array($result); 
					echo  "<div class='contenedor-datos'>";
					echo  "<div class='dato'>";
					echo  "<h2>".$nombre."</h2>";
					echo  "<h3>".$fila['estadio']."</h3>";
					echo  "<h4>".$fila['entrenador']."</h4>";
					echo  "<p class='clasic'> puntos : ".$fila['puntos']." | goles a favor :  ".$fila['gf']." | goles en contra :  ".$fila['gc'];
					echo  "</div>";
					echo  "<div class='contenedor-entrenador'>";
					echo  "<img class='entrenador' src='images/entrenadores/".$fila['entrenador_image']."' alt='".$fila['entrenador']."'>";
					echo  "</div>";
					echo  "</div>";

					$_SESSION['estadio'] = $fila['estadio_image'];
				}else{
					echo "no se encontró ningún registro";
				}
				mysql_free_result($result);
			}else{
				echo "ficha no encontrada";
			}
			//seleccionamos los jugadores del equipo y los mostramos
			$sql = "SELECT * FROM jugadors WHERE id_equipo=".$id;
			$result = mysql_query($sql);
			if($result){
				if(mysql_num_rows($result)!=0){
					$numJug = 0;
					while(($fila = mysql_fetch_array($result))!=FALSE && $numJug<4){
						echo "<div class='contenedor-jugador'>";
						echo "<img class='jugador' src='images/jugadores/".$fila['image']."' alt='".$fila['nombre']."'>";
						echo "<p>".$fila['nombre']."</p>";
						echo "</div>";
						$numJug++;
					}
					mysql_free_result($result);
				}else{
					echo "no se encontró ningún registro";
				}
			}


		}else {
			echo "error en la selección de base de datos";
		}
	} else {
		echo "error en la conexión";
	}
?>