<?php  
	//devolverá 1 si el admin está logeado ,0 de lo contrario
	include 'sessionAdmin.php';
	sessionAdmin::startSession();
	sessionAdmin::getCredential();
	if(sessionAdmin::adminLogged()){
		echo 1;
	}else {
		echo 0;
	}
?>