<?php  
	include 'config.php';
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD);
	if($conn){

			if(mysql_select_db(DB)===TRUE){
					//seleccionamos todos los equipos y los mostramos en una columna
					$sql = "SELECT * FROM equipos";
					mysql_query("SET CHARACTER SET utf8");
					mysql_query("SET NAMES utf8");
					$result = mysql_query($sql);
					if($result){

						if(mysql_num_rows($result)!=0){

							 while($fila=mysql_fetch_array($result)){
							 	echo "<div class='equipo'>";
							 	echo "<h3>".$fila['equipos']."</h3>";
							 	echo "<img class='image-equipo' src ='images/equipos/".$fila['image']."'>";
							 	echo "</div>";
							 }

							 mysql_free_result($result);
						}else{
							echo "no hay ningún equipo";
						}

					}else{
						echo "error en el query";
					}
			}else{
				echo "error en la selección de base de datos";
			}

	}else{
		echo "error en la conexión";
	}
?>