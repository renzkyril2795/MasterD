<?php 
	/**
	* Clase de utilidad para la sessión del administrador . Como es una clase de utilidad
	* todos sus atributos y métodos son estáticas
	*/
	 class sessionAdmin{

	 	private function __construct() {} // indicamos que es una clase de utilidad
		public static $username; 
		public static $password;
		public static $error;
		private static $admin;

		/**
		*	Iniciar sessión
		*/ 
		public static function startSession(){
			session_start();
		}

		/**
		*	Obtener credenciales del admin
		*/
		public static function getCredential(){
			include 'admin.php';
			self::$admin = new admin();
			self::$username = self::$admin->getUsername();
			self::$password = self::$admin->getPassword();
			self::$error = self::$admin->getError();
		}

		/**
		*	Si el admin está conectado le daremos la bienvenida
		*/
		public static function welcome(){
			if(self::adminLogged()){
				echo "<h2 class='php'> Bienvenido ".self::$username." </h2>";
			}else{
				echo "<h2 class='php'> MASTER.D PHP </h2>";
			}
		}

		/**
		*	Muestra el botón de log out si el admin está conectado
		*/
		public static function logOut(){
			if(self::adminLogged()){
				echo "<input  type='button' name='usuario' class='logOut' style='display: inline;'>";
			}else{
				echo "<input type='button' name='logOut' class='logOut' style='display: none;''>";
			}
		}

		/**
		*	El administrador podrá añadir o borrar partidos almacenados en la base de datos
		*/
		public static function modificarPartidos($future){
			if(self::adminLogged()){


				include 'config.php';
				$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD);
				if($conn){

					if(mysql_select_db(DB)===TRUE){
							//obtenemos todos los equipos
							$sql = "SELECT * FROM equipos";
							mysql_query("SET CHARACTER SET utf8");
							mysql_query("SET NAMES utf8");
							$result = mysql_query($sql);
							if($result){

								if(mysql_num_rows($result)!=0){

									 while($fila=mysql_fetch_array($result)){
									 		//y los asignamos a opciones para la selección de partido a borrar/añadir
									 		$opciones .= '<option value="'.$fila['id'].'"><img class="equipos" url="images/equipos'.$fila['equipoA_image'].'"> '.$fila['equipos'].'</option>';	


									 }

									 mysql_free_result($result);
								}else{
									echo "no hay ningún equipo";
								}

							}else{
								echo "error en el query";
							}
					}else{
						echo "error en la selección de base de datos";
					}

				}else{
					echo "error en la conexión";
				}

				//obtenemos todos los partidos o todos que todavia aun no se han hecho 
				$sql = "SELECT  equipoA.equipos AS equipoA ,equipoB.equipos AS equipoB, equipoA.image AS equipoA_image ,equipoB.image AS equipoB_image ,partidos.id ,partidos.fecha  FROM   equipos AS equipoA , equipos AS equipoB , partidos WHERE  partidos.id_equipo_1=equipoA.id AND partidos.id_equipo_2=equipoB.id";
				if($future==true){
					$sql.=" AND partidos.fecha > CURDATE()";
				}
				$result = mysql_query($sql) or die(" <p>Error en el query !</p>");
				if(mysql_num_rows($result)!=0){
					//y los asignamos como opciones para su posterior uso
					while ($fila = mysql_fetch_array($result)) {
						$opcionesP .= '<option value="'.$fila['id'].'"><img class="equipos" src="images/equipos/'.$fila['equipoA_image'].'"> '.$fila['equipoA'].' VS  <img class="equipos" src="images/equipos/'.$fila['equipoB_image'].'"> '.$fila['equipoB'].'  '.$fila['fecha'].'</option>';	
					}
					
				}
				//dependiendo si queremos añadir partidos aun no jugados mostraremos un html u otro
				$heads=' ';
				$fields=' ';
				if($future==false){
					$heads.='<td class="mod"> GOL HOME </td><td class="mod"> GOL VISITOR </td>';
					$fields.='<td class="mod"><input type="text" name="gol_1"></td><td class="mod"><input type="text" name="gol_2"></td>';
				}

				echo '<div class="partidos">
			<h2> Modificando partidos DB </h2>
			<h3> Añadir </h3>
			<form action="" method="POST" name="add" >
				<table >
					<tr>
						<td class="mod"> Home </td>
						<td class="mod"> Visitor </td> '.$heads.'
						<td class="mod"> Date </td>
					</tr>
					<tr>
						<td class="mod"><select class="equipos" name="home" >'.$opciones.'</select></td>
						<td class="mod"><select class="equipos" name="visitor">'.$opciones.'</select></td> '.$fields.'
						<td class="mod"><input type="text" name="date" placeholder="yyyy-dd-mm"></td>
					</tr>
					<tr>
						<td class="mod"></td>
						<td class="mod"><input type="button" class="addGame" value="Añadir"></td>
						<td class="mod"></td>
					</tr>
				</table>
			</form> 
			<h3> Borrar </h3>
			<form action="" method="POST" name="erase">
				<table>
					<tr><td><select name="partidos" >'.$opcionesP.'</select></td>
					<td><input type="button" class="eraseGame" value="Borrar"></td></tr>
				</table>
			</form>
		</div>';
			}
		}

		/**
		*	Cerramos la conexión
		*/
		public static function close(){
			self::$admin->close();
		}

		/**
		*	checkea si es el admin
		*/
		public static function isAdmin($usuario,$contrasena){
			return ($usuario == self::$username && $contrasena == self::$password);

		}

		/**
		*	mira si está logeado el admin
		*/
		public static function adminLogged(){
			return ($_SESSION['username'] == self::$username && $_SESSION['password'] == self::$password) ;

		}


	}

	
?>
