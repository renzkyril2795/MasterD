<?php 	
		define ("HOSTNAME" , "localhost");
		define('USERNAME', 'root');
		define('PASSWORD', 'tuPassword');
		define('DB', 'liga');
?>