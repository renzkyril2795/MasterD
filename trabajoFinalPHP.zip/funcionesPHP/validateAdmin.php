<?php 
	include 'sessionAdmin.php';
	//iniciamos sessión
	sessionAdmin::startSession();
	//obtenemos el usuario y contraseña del administrador
	sessionAdmin::getCredential();
	//filtramos las entradas
	$usuario = mysql_real_escape_string(strip_tags($_POST['username']));
	$contrasena = md5(mysql_real_escape_string(strip_tags($_POST['password'])));
	try {		
		//si ha introducido bien sus credenciales inicializamos las sessiones
		//si_no lanzamos una excepción ( para demostrar el manejo de excepciones)
		if(sessionAdmin::isAdmin($usuario,$contrasena)){

				$_SESSION['username'] = $usuario;
				$_SESSION['password'] = $contrasena;
				echo 1;
				
		}else {
				throw new Exception("Usuario o contraseña incorrecta");		
		}
	} catch (Exception $e) {
		echo $e->getMessage();
	}
	//cerramos la conexión
	sessionAdmin::close();
?>