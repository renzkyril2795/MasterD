<?php  
	/*
	* Edita la columna seleccionado
	*/
	$dato = $_GET['dato'];
	$tipo = $_GET['tipo'];
	$nombre = $_GET['nombre'];

	include 'config.php';

	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD);
	if($conn){

		if(mysql_select_db(DB)===TRUE){
			//obtenemos el id del equipo selccionado
			$id = "";
			$sql = "SELECT * FROM equipos WHERE equipos.equipos='".$nombre."'";
			mysql_query("SET CHARACTER SET utf8");
			mysql_query("SET NAMES utf8");
			$result = mysql_query($sql);
			if($result){
				if(mysql_num_rows($result)!=0){
					$id = mysql_fetch_array($result);
					$id = $id['id'];
					mysql_free_result($result);
				}else{
					echo "no hay ningún equipo con ese nombre";
				}
			}else{
				echo " nombre del equipo no existe : ".$nombre."\r\n";
			}
			// y actualizamos el dato 
			$sql = "UPDATE clasificacion SET ".$tipo."=".$dato." WHERE id_equipo=".$id;
			$result = mysql_query($sql);
			

		}else{
			echo "error en la seleción de db";
		}

	}else {
		echo "error en la conexión";
	}
	//cerramos conexión
	mysql_close($conn);

?>