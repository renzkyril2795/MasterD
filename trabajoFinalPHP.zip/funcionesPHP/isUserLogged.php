<?php  

	include 'config.php';
	//iniciamos sessión
	session_start();
	//seteamos el timezone a donde estamos
	date_default_timezone_set("Europe/Madrid");
	//abrimos conexión
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die("Error en la conexión");
	mysql_select_db(DB) or die("Error en la selección de bases de datos");
	//Miramos si el usuario está logeado
	$sql = "SELECT * FROM usuarios WHERE psw='".$_SESSION['pass']."' AND username='".$_SESSION['user']."'";
	mysql_query("SET CHARACTER SET utf8");
	mysql_query("SET NAMES utf8");
	$result = mysql_query($sql) or die("Error en el query");

	if(mysql_num_rows($result)!=0){
		//si lo está entonces 
		$_SESSION['conectado'] = "conectado";
		$id = mysql_fetch_array($result)['id'];
		mysql_free_result($result);
		//le daremos la bienvenida con los datos de su apuesta
		echo '<div class="contenedor-usuario">
				Hola '.$_SESSION['user'];
		$sql = "SELECT apuestas.apuesta ,apuestas.gol_1 ,apuestas.gol_2, equipoA.equipos AS equipoA ,equipoB.equipos AS equipoB, equipoA.image AS equipoA_image ,equipoB.image AS equipoB_image , partidos.fecha , partidos.gol_1 AS equipoA_gol ,partidos.gol_2 AS equipoB_gol FROM apuestas , equipos AS equipoA , equipos AS equipoB , partidos WHERE apuestas.id_usuario=".$id." AND apuestas.id_partido=partidos.id AND partidos.id_equipo_1=equipoA.id AND partidos.id_equipo_2=equipoB.id";
		$result = mysql_query($sql);

		if(mysql_num_rows($result)!=0){
			$user = mysql_fetch_array($result);
			echo ' , has apostado '.$user['equipoA_gol'].' - '.$user['equipoB_gol'].' , con una cantidad de '.$user['apuesta'].'€ al partido : <br>';
			echo '<div class="resultado">
					<table>
						<tr>
							<td><img class="equipo" src="images/equipos/'.$user['equipoA_image'].'"> '.$user['equipoA'].'						</td>
							<td> VS </td>
							<td><img class="equipo" src="images/equipos/'.$user['equipoB_image'].'"> '.$user['equipoB'].'						</td>
							<td>'.$user['fecha'].'</td>
						</tr>
					</table>
				</div>';
			//miramos si el partido ya se ha jugado , le damos el resultado , borramos la apuesta en la base de datos 
			//para que pueda apostar de nuevo
			$fecha = date_create($user['fecha']);
			$fecha = strtotime(date_format($fecha,'Y-m-d'));
			if(time()>$fecha){
	
				echo '<p> Resultado : '.$user['gol_1'].' - '.$user['gol_2'].' </p>';
				if($user['gol_1']==$user['equipoA_gol'] && $user['gol_2']==$user['equipoB_gol']){
					echo '<p> Has ganado la apuesta !!! enhorabuenaa !  </p>';
					// enviar premio
				}else{
					echo '<p> Lo siento has perdido . Intenta la próxima vez  </p>';
				}
				$sql = "SELECT  equipoA.equipos AS equipoA ,equipoB.equipos AS equipoB, equipoA.image AS equipoA_image ,equipoB.image AS equipoB_image , partidos.id ,partidos.fecha  FROM   equipos AS equipoA , equipos AS equipoB , partidos WHERE  partidos.id_equipo_1=equipoA.id AND partidos.id_equipo_2=equipoB.id AND partidos.fecha > CURDATE()";
				$result = mysql_query($sql) or die(" <script> alert('Error en el query !')</script>");
				if(mysql_num_rows($result)!=0){

					while ($fila = mysql_fetch_array($result)) {
						$opciones .= '<option value="'.$fila['id'].'"><img class="equipo_image" url="images/equipos'.$fila['equipoA_image'].'"> '.$fila['equipoA'].' VS  <img class="equipo_image" url="images/equipos'.$fila['equipoB_image'].'"> '.$fila['equipoB'].'  '.$fila['fecha'].'</option>';	
					}

					
				}
				include 'borrarApuesta.php';
				echo '<p> Alerta esta apuesta ya está borrado en la base de datos </p>';
				echo '¿ Quieres apostar de nuevo ?<br>
						<form action="apostar.php" method="POST" name="apostar" class="resultado">
						<table >
							<tr>
								<td class="text">Apostar a : </td>
								<td><select name="partidos">'.$opciones.'</select></td>
							</tr>
							<tr>
								<td class="text">Cantidad : </td>
								<td><input type="text" name="cantidad"></td>
							</tr>
							<tr>
								<td class="text">Predicción : </td>
								<td><input class="prediction" type="text" name="gol_1"><input class="prediction" type="text" name="gol_2"></td>
							</tr>
							<tr>
								<td class="text"></td>
								<td><input type="button" class="Apostar" value="Submit"></td>
							</tr>
						</table>
					</form>	 ';
			}


		}else{

			// si no ha apostado entonces le preguntaremos si quiere apostar
			$sql = "SELECT  equipoA.equipos AS equipoA ,equipoB.equipos AS equipoB, equipoA.image AS equipoA_image ,equipoB.image AS equipoB_image , partidos.id ,partidos.fecha  FROM   equipos AS equipoA , equipos AS equipoB , partidos WHERE  partidos.id_equipo_1=equipoA.id AND partidos.id_equipo_2=equipoB.id AND partidos.fecha > CURDATE()";
			$result = mysql_query($sql) or die(" <script> alert('Error en el query !')</script>");
			if(mysql_num_rows($result)!=0){

				while ($fila = mysql_fetch_array($result)) {
					$opciones .= '<option value="'.$fila['id'].'"><img class="equipo_image" url="images/equipos'.$fila['equipoA_image'].'"> '.$fila['equipoA'].' VS  <img class="equipo_image" url="images/equipos'.$fila['equipoB_image'].'"> '.$fila['equipoB'].'  '.$fila['fecha'].'</option>';	
				}

				
			}
			echo ' , ¿ Quieres apostar ? <br>
					<form action="apostar.php" method="POST" name="apostar" class="resultado">
						<table>
							<tr>
								<td class="text">Apostar a : </td>
								<td><select class="partidos">'.$opciones.'</select></td>
							</tr>
							<tr>
								<td class="text">Cantidad : </td>
								<td><input type="text" name="cantidad"></td>
							</tr>
							<tr>
								<td class="text">Predicción : </td>
								<td><input class="prediction" type="text" name="gol_1"><input class="prediction" type="text" name="gol_2"></td>
							</tr>
							<tr>
								<td class="text"></td>
								<td><input type="button" class="Apostar" value="Submit"></td>
							</tr>
						</table>
					</form>	
				';
		}

			
	}else{
		//Si no está logeado entonces mostraremos dos formularios uno para logear y el otro será para registrar
		$sql = "SELECT  equipoA.equipos AS equipoA ,equipoB.equipos AS equipoB, equipoA.image AS equipoA_image ,equipoB.image AS equipoB_image , partidos.id ,partidos.fecha  FROM   equipos AS equipoA , equipos AS equipoB , partidos WHERE  partidos.id_equipo_1=equipoA.id AND partidos.id_equipo_2=equipoB.id AND partidos.fecha > CURDATE()";
		$result = mysql_query($sql) or die(" <script> alert('Error en el query !')</script>");
		if(mysql_num_rows($result)!=0){

			while ($fila = mysql_fetch_array($result)) {
				$opciones .= '<option value="'.$fila['id'].'"><img class="equipo_image" url="images/equipos'.$fila['equipoA_image'].'"> '.$fila['equipoA'].' VS  <img class="equipo_image" url="images/equipos'.$fila['equipoB_image'].'"> '.$fila['equipoB'].'  '.$fila['fecha'].'</option>';	
			}

			
		}

		echo '<div class="form login">
			<h3> Log - in</h3>
			<form action="../funcionesPHP/validateUser.php" method="POST" name="log">
				<table>
					<tr>
						<td class="text">*Username : </td>
						<td><input type="text" name="usuario"></td>
					</tr>
					<tr>
						<td class="text">*Password : </td>
						<td><input type="password" name="contra"></td>
					</tr>
					<tr>
						<td class="text"> </td>
						<td><input type="button" class="logear" value="Submit"></td>
					</tr>
				</table>
				
				
				
			</form>
		</div>
		<div class=" form register">
			<h3> Register </h3>
			<form action="" method="POST" name="register">
			<table>
				<tr>
					<td class="text">*Username : </td>
					<td><input type="text" name="usuario" required></td>
				</tr>
				<tr>
					<td class="text">*Password : </td>
					<td><input type="password" name="contra" required></td>
				</tr>
				<tr>
					<td class="text">Apostar a : </td>
					<td><select name="partidos">'.$opciones.'</select></td>
				</tr>
				<tr>
					<td class="text">Predicción : </td>
					<td><input class="prediction" type="text" name="gol_1"><input class="prediction" type="text" name="gol_2"></td>
				</tr>	
				<tr>
					<td class="text">Cantidad : </td>
					<td><input type="text" name="cantidad"></td>
				</tr>
				<tr>
					<td class="text"></td>
					<td><input type="button" class="registrar" value="Submit"></td>
				</tr>
			</table>
				
			</form>
		</div>';
	}
?>