<?php  
	//borra el partido seleccionado
	include 'config.php';
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die("Error en la conexión ");
	mysql_select_db(DB) or die("Error en la selección de base de datos");
	$sql = " DELETE FROM partidos WHERE id=".$_POST['partidos'];
	mysql_query($sql) or die("Error en la operación de DB");
	echo "Partido borrado !";
?>