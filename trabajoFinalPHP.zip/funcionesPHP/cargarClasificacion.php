<?php  

	include 'config.php';
	$conn = mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die(" Error en la conexión ");
    mysql_select_db(DB) or die("no se pudo selecionar base de datos");
	//ordenar por puntos
	//cargamos la clasificación de todos los equipos
			$sql = " SELECT * FROM equipos  INNER JOIN clasificacion ON clasificacion.id_equipo = equipos.id ORDER BY clasificacion.puntos DESC"; 
			mysql_query("SET CHARACTER SET utf8");
			mysql_query("SET NAMES utf8");
			$result = mysql_query($sql);
			if($result){

				if(mysql_num_rows($result)!=0){
					$c = 1; 
					echo "<section class='clasificacion'>";
					echo "<h3>Liga Española</h3>";
					echo "<p>Clasificación</p>";
					echo "<table><tr class='par'><td> CLASIFICACIÓN </td><td> EQUIPOS </td><td>PJ</td><td>V</td><td>E</td><td>D</td><td> GOLES A FAVOR </td><td> GOLES EN CONTRA </td><td> PUNTOS </td></tr>";
					while ($fila=mysql_fetch_array($result)) {
						echo "<tr class='".$fila['equipos']."'><td>".$c."</td>";						

						echo "<td><img class='equipo' src ='images/equipos/".$fila['image']."' alt='".$fila['equipos']."'>".$fila['equipos']."</td>";
						echo "<td class='PJ'>".$fila['PJ']."</td><td class='V'>".$fila['V']."</td><td class='E'>".$fila['E']."</td><td class='D'>".$fila['D']."</td>";
						echo "<td class='goles_favor'>".$fila['goles_favor']."</td><td class='goles_contra'>".$fila['goles_contra']."</td><td class='puntos'>".$fila['puntos']."</td></tr>";
						$c++;
					}
					echo "</table></section>";




				}else{
					echo "no hay filas";
				}
			}else{
				echo "error en query";
			}
	mysql_close($conn);
?>