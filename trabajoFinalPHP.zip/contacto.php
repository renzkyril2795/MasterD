<?php 
	include 'funcionesPHP/sessionAdmin.php';
	sessionAdmin::startSession();
	sessionAdmin::getCredential();
?>
<!DOCTYPE html>
<html>
<head>
	<title> </title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/contacto.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script type="text/javascript" src="javascript/funciones.js"></script>
	<script type="text/javascript" src="javascript/contacto.js"></script>
</head>
<body >
	<div class="pop-up" >
		<input type="button" class="close-pop">
		<h2>Administrator log - in</h2>
		<form action="admin.php" name="adminForm" method="POST" class="formAdmin">
			
			<table>
				<tr>
					<td>*Username : </td>
					<td><input required type="text" name="username"></td>
				</tr>
				<tr>
					<td>*Password : </td>
					<td><input requiered type="password" name="password"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="button" name="enviar" class="validarAdmin" value="Submit"></td>
				</tr>
			</table>
			
		</form>
	</div>
	<header >
		<div class="portada">	
			
			<a href="#" ><img class="admin" src="../images/fondos/admin.png"></a>
			<?php  
				sessionAdmin::logOut();
				
			?>
			<div class="portada-2">
				<?php  
					sessionAdmin::welcome();
				?>
			</div>
		</div>
		<nav>
			<ul class="b-paginas">
				<li><a class="b-pagina" href="index.php">INICIO</a></li>
				<li><a class="b-pagina" href="equipos.php">EQUIPOS</a></li>
				<li><a class="b-pagina" href="clasificacion.php">CLASIFICACIÓN</a></li>
				<li><a class="b-pagina" href="partidos.php">PARTIDOS</a></li>
				<li><a class="b-pagina" href="noticias.php">NOTICIAS</a></li>
				<li><a class="b-pagina" href="apuestas.php">APUESTAS</a></li>
				<li><a class="b-pagina" href="contacto.php">CONTACTO</a></li>
			</ul>
		</nav>
	</header>

	<div class="contenedor">
		<form action="" name="email">
			<h3>Formulario de contacto </h3>
			<p> Envianos un email para consultar más información o contacta al número : 988654329128</p>
			<table>
				<tr>
					<td>Nombre</td>
					<td><input type="text" name="name" required></td>
				</tr>
				<tr>
					<td>*Email : </td>
					<td><input type="text" name="email" required></td>
				</tr>
				<tr>
					<td>*Subject : </td>
					<td><input type="text" name="subject" required></td>
				</tr>
				<tr>
					<td>*Descripción</td>
					<td><textarea name="descripcion" rows="20" cols="80"></textarea></td>
				</tr>

				<tr>
					<td></td>
					<td><input type="button" name="submit" value="Submit"></td>
				</tr>
			</table>
		</form>
	</div>
</body>
</html>