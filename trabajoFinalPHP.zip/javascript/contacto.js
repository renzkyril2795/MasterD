$(document).ready(function(){

	$('input[name="submit"]').bind('click',send);

	function send(){
		var form = $('form[name="email"]');
		var email = form.find('input[name="email"]').val();
		var subject = form.find('input[name="subject"]').val();
		var desc = form.find('textarea').val();
		var name = form.find('input[name="name"]').val();

		if(name!="" && email!="" && subject!="" && desc!=""){

			$.ajax({
				type : "POST",
				url : "../funcionesPHP/enviarEmail.php",
				data : form.serialize(),
				success : function (result){
					alert(result);
				}
			});
		}
	}
});