$(document).ready(function(){

		var isModoAdmin = isAdminLogged();
		//MIRA SI EL ADMIN SE HA LOGEADO 
		function isAdminLogged(){
			var resultado = false;
			$.ajax({
				type : "GET",
				url : "../funcionesPHP/isAdminLogged.php",
				async: false,			
				success : function (isLogged){

					if(isLogged==1){
						resultado = true;
					}
				}
			});
			return resultado;
		}

		$.ajax({

			type : "GET",
			url : "../funcionesPHP/cargarClasificacion.php",
			async : false,
			success : function (clasic){
				
				$('.contenedor').html(clasic);
				$('.goles_favor').bind('click',editar);
				$('.goles_contra').bind('click',editar);
				$('.puntos').bind('click',editar);
				$('.PJ').bind('click',editar);
				$('.V').bind('click',editar);
				$('.E').bind('click',editar);
				$('.D').bind('click',editar); 
				$('td').bind('mouseenter',puntero);
			} 
		});

		function puntero(){
			if(isModoAdmin){
				$('td').css('cursor', 'pointer');
			}
		}


		function editar(){

			$(this).addClass("editing");
		    if(isModoAdmin){
		      $('.edit-form').addClass("log");
		    }else{
		      $('.edit-form').removeClass("log");
		    }
  		}

  		function validarDato(){

	  		var nombre = $('.editing').parent().attr("class");

	  		//Saber que tenemos que editar
	  		var tipo;
	  		if($('.editing').hasClass("goles_favor")){
	  			tipo = "goles_favor";
	  		}else if($('.editing').hasClass("goles_contra")){
	  			tipo = "goles_contra";
	  		}else if($('.editing').hasClass("PJ")){
	  			tipo = "PJ";
	  		}else if($('.editing').hasClass("V")){
	  			tipo = "V";
	  		}else if($('.editing').hasClass("E")){
	  			tipo = "E";
	  		}else if($('.editing').hasClass("D")){
	  			tipo = "D";
	  		}else {
	  			tipo = "puntos";
	  		}
	  		//tiene que ser un número
	  		var pat = new RegExp('[0-9]+$');
	  		var dato = $('form[name="editForm"]').find('input[name="data"]').val();
	  		if(pat.test(dato)){
	  			$('.editing').html(dato);
	  			//editar en la base de datos
	  			$.ajax({
	  				type : "GET",
	  				url: "../funcionesPHP/editarIndex.php?dato="+dato+"&tipo="+tipo+"&nombre="+nombre,
	  				success : function (resultado) {
	  					location.reload();
	  				}
	  			});
	  		}else{
	  			alert("dato no válido !");
	  		}


  		}

  		function closeEditForm(){
	  		$('.edit-form').removeClass("log");
	  		$('.editing').removeClass(".editing");
	  	}

	  	$('.close-edit').bind('click',closeEditForm);
  		$('.dato').bind('click',validarDato);


});