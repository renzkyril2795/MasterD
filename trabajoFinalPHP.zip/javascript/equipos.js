$(document).ready(function(){

	var isModoAdmin = isAdminLogged();
	//MIRA SI EL ADMIN SE HA LOGEADO 
	function isAdminLogged(){
		var resultado = false;
		$.ajax({
			type : "GET",
			url : "../funcionesPHP/isAdminLogged.php",
			async: false,			
			success : function (isLogged){

				if(isLogged==1){
					resultado = true;
				}
			}
		});
		return resultado;
	}

	$.ajax({
		type : "POST",
		url : "../funcionesPHP/cargarEquipos.php",
		success : function (result){
			$('#equipos').html(result);
			$('.equipo').bind('click',mostrarFicha);
		}
	});



	function mostrarFicha(){

		var nombre = $(this).find('h3').html();
		$.ajax({

			type : "POST",
			url : "../funcionesPHP/cargarEquiposDatos.php",
			data : { name : nombre},
			success : function (result) {
				$('#datos').html(result);
				$.ajax({

					type : "GET",
					url : "../funcionesPHP/getEstadio.php",
					success : function (estadio) {
						$('.contenedor-datos').css('background-image','url("images/estadio/'+estadio+'")');
					}
				});
			}
		});


	}

});