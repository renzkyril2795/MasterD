$(document).ready(function(){

	var isModoAdmin = isAdminLogged();
	//MIRA SI EL ADMIN SE HA LOGEADO 
	function isAdminLogged(){
		var resultado = false;
		$.ajax({
			type : "GET",
			url : "../funcionesPHP/isAdminLogged.php",
			async: false,			
			success : function (isLogged){

				if(isLogged==1){
					resultado = true;
				}
			}
		});
		return resultado;
	}

	
	//CARGA LA TABLA
	$.ajax({
			type : "GET",
			url : "../funcionesPHP/cargarIndex.php",
			success : function (resultado){

				$('.contenedor').html(resultado+"<section id='feed'><h3> Noticias </h3></section>");
				$('.goles_favor').bind('click',editar);
				$('.goles_contra').bind('click',editar);
				$('.puntos').bind('click',editar);
				$('td').bind('mouseenter',puntero);
			}
	});
	


	function editar(){
			$(this).addClass("editing");
		    if(isModoAdmin){
		      $('.edit-form').addClass("log");
		    }else{
		      $('.edit-form').removeClass("log");
		    }
  	}

  	function closeEditForm(){
  		$('.edit-form').removeClass("log");
  		$('.editing').removeClass(".editing");
  	}

  	function validarDato(){

  		var nombre = $('.editing').parent().attr("class");

  		//Saber que tenemos que editar
  		var tipo;
  		if($('.editing').hasClass("goles_favor")){
  			tipo = "goles_favor";
  		}else if($('.editing').hasClass("goles_contra")){
  			tipo = "goles_contra";
  		}else {
  			tipo = "puntos";
  		}
  		//tiene que ser un número
  		var pat = new RegExp('[0-9]+$');
  		var dato = $('form[name="editForm"]').find('input[name="data"]').val();
  		if(pat.test(dato)){
  			$('.editing').html(dato);
  			//editar en la base de datos
  			$.ajax({
  				type : "GET",
  				url: "../funcionesPHP/editarIndex.php?dato="+dato+"&tipo="+tipo+"&nombre="+nombre,
  				success : function (resultado) {
  					location.reload();
  				}
  			});
  		}else{
  			alert("dato no válido !");
  		}


  	}

  	function puntero(){
  		if(isModoAdmin){
			$('td').css('cursor', 'pointer');
  		}
	}


  	$('.close-edit').bind('click',closeEditForm);
  	$('.dato').bind('click',validarDato);


	$.ajax({
		type : "POST",
		data : { rss : "http://estaticos.marca.com/rss/futbol/primera-division.xml" , num : 3},
		url : "../funcionesPHP/cargarNoticia.php",
		success : function (resultado){
			$('#feed').append(resultado);
			$('.noticia').bind('mouseleave',showLeer)
			$('.noticia').bind('mouseenter',showLeer);
			
		}
	});

	function showLeer(){
		$(this).find('.description').slideToggle(1000);
		console.log($(this).find('a'));
		$(this).find('a').attr("target","_blank");
	}



});

