

$(document).ready(function(){

  var pop = true;

  $(window).scroll(function() {
		if ($(this).scrollTop() > 1){  
   			 $('nav').addClass("sticky-1");
   			 $('.php').addClass("sticky-1");
   			 $('.portada').addClass("sticky-2");
  		}
  		else{
   			 $('nav').removeClass("sticky-1");
   			 $('.php').removeClass("sticky-1");
   			 $('.portada').removeClass("sticky-2");
 		 }
	});

  /**
  *   Muestra el formulario
  */
  function admin(){

  	if(pop){
  		$('.pop-up').addClass("log");
  		pop = false;
  	}else{
  		$('.pop-up').removeClass("log");
  		pop = true;
  	}
  }
  /**
  *   Mira si ha puesto bien el usuario y la contra . Si true entonces 
  *   se pondrá en modo admin
  */
  function validarAdmin(){
      $.ajax({
        data : $('form[name="adminForm"]').serialize(),
        type : "POST",
        url : "../funcionesPHP/validateAdmin.php",
        success : function (result) {
            if(result==1){
              modoAdmin();
              pop = true;
            }else {
              $('.error').remove();
              $('.formAdmin').append("<p class='error'> Error . "+result+" </p>");
            }
        }
      });
  }
  /**
  *   Si lo ha puesto entonces la página está en modo administrador
  */
  function modoAdmin(){
              
              //cerrar pop up
              $('.pop-up').removeClass("log");
              //quitar el mensaje de error
              $('.error').remove();
              //refrescar pagina para el administrador

              location.reload();

              
  }

  function logOut(){

    $.ajax({
      type : "GET",
      url : "../funcionesPHP/logOut.php",
      success : function (result) {
        alert (result);

        location.reload();
      }
    });
  }

  
  $('.admin').bind('click',admin);
  $('.close-pop').bind('click',admin);
  $('.validarAdmin').bind('click',validarAdmin);
  $('.logOut').bind('click',logOut);

});