$(document).ready(function(){



		$.ajax({

			type:"GET",
			url: "../funcionesPHP/isUserLogged.php",
			success: function (result){
				$('.contenedor').html(result);
				$('.registrar').bind('click',register);
				$('.logear').bind('click',validateUser);
				$('.Apostar').bind('click',apostar)
			}
		});



		function register(){


			var form = $('form[name="register"]');
			var usuario = form.find('input[name="usuario"]').val();
			var contra = form.find('input[name="contra"]').val();
			var partido = form.find('select[name="partidos"]').val();
			var golA = form.find('input[name="gol_1"]').val();
			var golB = form.find('input[name="gol_2"]').val();
			var cantidad = form.find('input[name="cantidad"]').val();


			if(registroValido(usuario,contra,partido,golA,golB,cantidad)){
				$.ajax({
					type : "POST",
					url : "../funcionesPHP/registrar.php",
					data : form.serialize(),
					success : function (result) {
						location.reload();
					}
				});
			}else{
				alert("Error en la submissión del formulario");
			}
		}

		function apostar(){

			var form = $('form[name="apostar"]');
			var partido = form.find('select[name="partidos"]').val();
			var golA = form.find('input[name="gol_1"]').val();
			var golB = form.find('input[name="gol_2"]').val();
			var cantidad = form.find('input[name="cantidad"]').val();


			if(apuestaValido(partido,golA,golB,cantidad)){
				$.ajax({
					type : "POST",
					url : "../funcionesPHP/registrar.php",
					data : form.serialize(),
					success : function (result) {
						alert(result);
						location.reload();
					}
				});
			}else{
				alert("Error en la apuesta !");
			}

		}

		function apuestaValido(partido,golA,golB,cantidad){
			if(partido!="" || golA!="" || golB!="" || cantidad!=""){

				if(partido=="" || golA=="" || golB=="" || cantidad==""){
					return false;
				}

				var pat = new RegExp('[0-9]+$');
				if(!pat.test(golA) || !pat.test(golB) || !pat.test(cantidad)){
					return false;
				}
			}
			return true
		}

		function registroValido(usuario,contra,partido,golA,golB,cantidad){


			if(!(usuario!="" && contra!="")){
				return false;
			}

			return apuestaValido(partido,golA,golB,cantidad);

			
		}

		function validateUser(){
			

			var form = $('form[name="log"]');
			var usuario = form.find('input[name="usuario"]').val();
			var contra = form.find('input[name="contra"]').val();

			if(usuario!="" && contra!=""){
				$.ajax({
					type : "POST",
					url : "../funcionesPHP/validateUser.php",
					data : form.serialize(),
					success : function (result){
						alert(result);
						location.reload();
					}
				});
			}else{
				alert("Los campos obligatorios * tinen que estar rellenados !");
			}
		}


		function addGame(){

			var form = $('form[name="add"]');
			var date = form.find('input[name="date"]').val();
			var home = form.find('select[name="home"]').val();
			var visitor = form.find('select[name="visitor"]').val();

			var fecha = new Date(date);
			var hoy = new Date();
			var pat = new RegExp('[1-9]{4}-(0?[1-9])|(1[0-2])-([12][1-9])|(0?[1-9])|(3[01])');
			if(pat.test(date) && home!="" && visitor!="" && fecha.getTime()>hoy.getTime()){
				$.ajax({

					type : "POST",
					url : "../funcionesPHP/addGame.php",
					data : form.serialize(),
					success : function (result) {
						alert(result);
						location.reload();
					}
				});
			}else{
				alert("fecha no válida ! . Tiene que ser del formato indicado o fecha > hoy ");
			}
		}

		function eraseGame(){
			var form = $('form[name="erase"]');
	
			$.ajax({

				type : "POST",
				url : "../funcionesPHP/eraseGame.php",
				data : form.serialize(),
				success : function (result) {
					alert(result);
					location.reload();
				}
			});
		}



		$('.addGame').bind('click',addGame);
		$('.eraseGame').bind('click',eraseGame);
});