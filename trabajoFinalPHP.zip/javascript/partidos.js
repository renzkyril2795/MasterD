$(document).ready(function () {
	

	$.ajax({
		type:"GET",
		url:"../funcionesPHP/cargarPartidos.php",
		success : function (partidos){
			$('.contenedor').html(partidos);
		}
	});

	function addGame(){

			var form = $('form[name="add"]');
			var date = form.find('input[name="date"]').val();
			var home = form.find('select[name="home"]').val();
			var visitor = form.find('select[name="visitor"]').val();

			var fecha = new Date(date);
			var hoy = new Date();
			var pat = new RegExp('[1-9]{4}-(0?[1-9])|(1[0-2])-([12][1-9])|(0?[1-9])|(3[01])');
			if(pat.test(date) && home!="" && visitor!=""  && fecha.getTime()<hoy.getTime()){
				$.ajax({

					type : "POST",
					url : "../funcionesPHP/addGame.php",
					data : form.serialize(),
					success : function (result) {
						location.reload();
					}
				});
			}else{
				alert("fecha no válida ! o campo no rellenado . Tiene que ser del formato indicado o fecha < hoy ");
			}
		}

		function eraseGame(){
			var form = $('form[name="erase"]');
	
			$.ajax({

				type : "POST",
				url : "../funcionesPHP/eraseGame.php",
				data : form.serialize(),
				success : function (result) {
					alert(result);
					location.reload();
				}
			});
		}



		$('.addGame').bind('click',addGame);
		$('.eraseGame').bind('click',eraseGame);





});