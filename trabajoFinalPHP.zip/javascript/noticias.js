$(document).ready(function(){


		$.ajax({
			type : "GET",
			url : "../funcionesPHP/cargarNoticias.php",
			success : function (noticias){
				$('.contenedor').html(noticias);
				$('.noticia').bind('click',toPrincipal);
				$('.noticia').attr('href','.noticia-principal');
			}
		});

		function toPrincipal(){
			$principal = $('.noticia-principal').html();
			$('.noticia-principal').html($('.noticia').html());
			$('.noticia').html($principal);
		}



});