<?php 
	include 'funcionesPHP/sessionAdmin.php';
	sessionAdmin::startSession();
	sessionAdmin::getCredential();
?>
<!DOCTYPE html>
<html>
<head>
	<title> </title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/partidos.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script type="text/javascript" src="javascript/funciones.js"></script>
	<script type="text/javascript" src="javascript/partidos.js"></script>
</head>
<body >
	<div class="pop-up" >
		<input type="button" class="close-pop">
		<h2>Administrator log - in</h2>
		<form action="admin.php" name="adminForm" method="POST" class="formAdmin">
			
			<table>
				<tr>
					<td>*Username : </td>
					<td><input required type="text" name="username"></td>
				</tr>
				<tr>
					<td>*Password : </td>
					<td><input requiered type="password" name="password"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="button" name="enviar" class="validarAdmin" value="Submit"></td>
				</tr>
			</table>
			
		</form>
	</div>
	<header >
		<div class="portada">	
			
			<a href="#" ><img class="admin" src="../images/fondos/admin.png"></a>
			<?php  
				sessionAdmin::logOut();
				
			?>
			<div class="portada-2">
				<?php  
					sessionAdmin::welcome();
				?>
			</div>
		</div>
		<nav>
			<ul class="b-paginas">
				<li><a class="b-pagina" href="index.php">INICIO</a></li>
				<li><a class="b-pagina" href="equipos.php">EQUIPOS</a></li>
				<li><a class="b-pagina" href="clasificacion.php">CLASIFICACIÓN</a></li>
				<li><a class="b-pagina" href="partidos.php">PARTIDOS</a></li>
				<li><a class="b-pagina" href="noticias.php">NOTICIAS</a></li>
				<li><a class="b-pagina" href="apuestas.php">APUESTAS</a></li>
				<li><a class="b-pagina" href="contacto.php">CONTACTO</a></li>
			</ul>
		</nav>
	</header>

	<div class="contenedor">

	</div>
	<?php  
			sessionAdmin::modificarPartidos(false);
	?>
</body>
</html>